# 学术主页内容整理与核对

整理日期：2026-10-27。主要来源：用户提供的《中文简历_张浩_山东大学.pdf》两页，以及用户指定的 [Google Scholar](https://scholar.google.com/citations?user=V0mUC7EAAAAJ&hl=zh-CN)。Scholar 抓取返回 429，因此没有据此推断新论文或实时引用量。

## 身份与研究主线

张浩 / Hao Zhang，山东大学软件学院特别资助类博士后（2025.09 至今），合作导师崔立真教授。2025 年获山东大学电子信息博士学位，导师张伟、宋然教授。硕士为首都师范大学计算机应用技术，本科为曲阜师范大学软件工程；曾在中科院宁波材料所联合培养。

根据论文实际内容归纳四个研究主题：

1. 脑网络图学习：LG-GNN、异配性感知谱 GCN、不变子图 GNN、认知分数预测。
2. 脑疾病异质性：阿尔茨海默病亚型解耦与 MIND 结构连接分析。
3. 医学影像分割：三维管状结构与脑血管的边缘感知分割；CT 图像 OPLL 自动诊断归入医学影像分析相关工作。
4. 医学视觉语言学习：AGIRA 解剖引导影像—报告对齐。

英文介绍已经写入 `profile.bio`。其中长期研究目标是对已列工作的归纳表达，不代表新增项目或已实现临床效果。简历提及机器人辅助手术中的视觉感知，但未给出具体论文/项目，所以未另设此方向卡片。

## 全部论文（10 篇，年份倒序）

完整题名和原始作者顺序集中于 `content/publications.ts`。没有省略作者；张浩在页面加粗。共同第一作者和通讯标记依据简历。

| 年份 | 工作 | 刊物/会议 | 核实的公开入口 |
| --- | --- | --- | --- |
| 2026 | Heterophily-Aware Spectral GCN | IEEE JBHI | [PubMed](https://pubmed.ncbi.nlm.nih.gov/41701587/) |
| 2026 | Unsupervised Disentanglement of Brain Heterogeneity | IEEE TBME | [PubMed](https://pubmed.ncbi.nlm.nih.gov/41666058/)、[论文指定代码](https://github.com/cnuzh/3D-DisAD) |
| 2026 | AGIRA | Fractal and Fractional | [出版方](https://www.mdpi.com/2504-3110/10/9/597) |
| 2026 | Mapping Structural Disconnection…MIND Networks | Brain Research Bulletin | [PubMed](https://pubmed.ncbi.nlm.nih.gov/41548720/) |
| 2025 | Invariant Subgraph GNN | IEEE TSIPN | DOI 尚未通过可读取的出版方正文确认，暂不展示 |
| 2025 | Automated Diagnosis of OPLL | BSPC | DOI 尚未通过可读取的出版方正文确认，暂不展示 |
| 2023 | Local-to-Global GNN | IEEE TMI | [PubMed](https://pubmed.ncbi.nlm.nih.gov/36327188/) |
| 2022 | 3D vessel-like structure segmentation | MedIA | [出版方](https://www.sciencedirect.com/science/article/pii/S1361841522002201) |
| 2022 | Intelligence Quotient Scores Prediction | CICAI | [Springer](https://link.springer.com/chapter/10.1007/978-3-031-20503-3_38) |
| 2020 | Reverse Edge Attention Network | MICCAI | [官方代码仓库](https://github.com/iMED-Lab/RE-Net)、[会议 Oral 日程](https://www.miccai2020.org/files/downloads/MICCAI2020-Draft-Oral-Program-Revised-August4th.pdf) |

**需确认的署名差异：** JBHI 2026 公开记录在 Jianyang Xie 之后另列 Tiyu Fang；简历没有此作者。网站暂保留简历原序并附核对说明，未擅自添加或删除。MIND 论文公开记录另列团体署名“for Alzheimer’s Disease Neuroimaging Initiative”，网站亦已注明。正式使用 BibTeX 前应先确认这两条。

简历的 ESI 高被引标记作为有来源的历史说明呈现，不声称已核实当前 ESI 状态。没有展示会变动的引用计数、影响因子和分区，也没有将获奖泛化为 Best Paper。MedIA 与 MICCAI 的共同作者顺序、MICCAI Oral 均已保留。

## 项目、专利、荣誉、服务

4 项主持项目及经费：GZB20260453（2026–2028，36 万）、2026M791843（2026–2028，8 万）、BK20261360（2026–2029，20 万）、SDZZ-ZR-202501303（2025–2027，3 万）。这些是资助计划名称，不能当作具体课题研究标题；研究目标、技术路线、成果对应关系未提供。

2 项授权专利：ZL 2025 1 1073626.X；ZL 2021 1 0360853.6。名称和发明人依原简历，未编造法律状态查询链接。

7 条荣誉按简历整理；纪德法奖学金名称经放大原文核对。简历同时给出 2023、2024 年，未推断各奖分别对应哪个年份。青年编委：Advanced Technology in Neuroscience、NeuroMarkers（2026.08 至今）；审稿人：IEEE TMI、TIP、TMM、JBHI、MICCAI（2021 至今）。

新闻仅使用简历能够支持的任职、论文年份和项目年份，不补写接收日期。

## 需补充的信息

- [待补充] 本人的 GitHub 主页、ORCID；当前不展示猜测链接。论文代码仓库不自动当作个人主页。
- [待确认] JBHI 的完整最终作者名单、MIND 的团体署名引用方式。
- [待补充] TSIPN 与 BSPC 的最终 DOI/出版方入口；可同时补充各篇最终卷期页码以完善 BibTeX。
- [待补充] 4 项项目的具体课题名称、研究目标、技术路线、已公开成果与对应论文。
- [待补充] Springer 参编专著名称、章节、出版年份、链接；目前只有总述，未生成具体书目。
- [可选] 论文配图、实验结果图及使用许可；当前抽象脑网络图为页面装饰，不伪装为实验数据。
- [可选] 自定义域名；不影响使用托管平台网址。

所有待补充信息集中于本文；没有将虚构内容填入公开页面。原始私人电话、出生日期、籍贯、民族、政治面貌、婚姻信息均未加入网站或公开下载版。

## 用户修订：中文紧凑版

根据用户要求，主页固定中文并移除语言切换和研究方向独立栏目；论文移除全部外部链接和 BibTeX 操作。个人简介直接采用原简历三段原文，其中 SCI/EI 数量、引用量、TOP50、博新计划会评等均保留原文口径，不代表实时查询数据。原文配置为 `profile.biographyZh`，旧英文介绍仅作源数据保留。

## Google Scholar 完整列表核对（2026-10-27）

已通过浏览器成功读取用户提供的 Google Scholar 主页全部 15 条记录（显示“文章 1–15”，展开按钮禁用），并逐条读取新增 6 条记录的完整作者、刊物与年份。与原简历去重合并为 16 条（保留原简历中尚未出现在 Scholar 的 AGIRA）。新增：医学高光谱分类（2024）、嵌套多尺度脑血管分割（2021）、血管拓扑推理（2026）、视网膜多病诊断（2026）、PMDNet（2025）、3D Generative Network 专著章节（2024）。JBHI 的 Tiyu Fang 署名也已由用户 Scholar 完整记录确认并补齐。

主页统一列表中，原有 6 篇代表作排在前面，各组内按年份倒序。没有复制 Scholar 的省略作者名单；新记录采用详情页全部作者，原样保留姓名（例如高光谱论文中的 Lichao Mou）。来源是 [用户的 Google Scholar](https://scholar.google.com/citations?user=V0mUC7EAAAAJ&hl=zh-CN&pagesize=100)。最新动态已移动到个人简介后；本科与首都师范大学教育经历不在主页学术经历栏目展示。
