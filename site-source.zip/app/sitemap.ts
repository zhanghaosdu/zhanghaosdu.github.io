import type { MetadataRoute } from 'next';
export const dynamic='force-static';
export default function sitemap():MetadataRoute.Sitemap{return [{url:process.env.NEXT_PUBLIC_SITE_URL||'https://zhanghaosdu.github.io',lastModified:'2026-10-27',changeFrequency:'monthly',priority:1}];}
