export const locales = {
 en: {
 nav:['About','Research','Publications','Projects','Experience','Contact'],
 tagline:'ARTIFICIAL INTELLIGENCE · MEDICAL IMAGE ANALYSIS',heroLine:'Understanding the brain.\nLearning from its connections.',researchLabel:'RESEARCH FOCUS',
 areas:['Graph Neural Networks','Brain Imaging','Medical Computer Vision'],cv:'Download CV',scholar:'Google Scholar',email:'Email',
 about:'About me',aboutKicker:'A RESEARCH THREAD',research:'Research interests',researchSub:'From fine anatomical structures to population-level brain networks.',related:'Related publications',
 pubs:'Publications',pubSub:'Graph learning, brain disorders, and medical image understanding.',selected:'Selected',all:'All publications',allYears:'All years',allTopics:'All topics',empty:'No publications match these filters.',shown:'publications',bib:'BibTeX',copy:'Copy BibTeX',copied:'Copied',copyFail:'Please select and copy the citation below.',
 projects:'Research funding',projectSub:'Principal investigator on four funded projects.',pi:'Principal investigator',funds:'CNY',projectNote:'The CV provides funding programs and grant numbers; specific project titles, objectives, and outcomes are not supplied.',
 experience:'Academic journey',awards:'Awards & honors',service:'Academic service',patents:'Granted patents',news:'News & updates',newsNote:'Dates are shown only at the precision provided in the CV.',
 contact:'Let’s connect.',contactSub:'For research discussions and potential academic collaborations.',updated:'Last updated',top:'Back to top',theme:'Toggle color theme',menu:'Toggle navigation',skip:'Skip to content',close:'Close citation',citationNote:'Minimal citation from CV metadata. Check the publisher record before submitting a bibliography.',legend:'† Equal contribution · * Corresponding author. Distinctions are reported in the supplied CV.',sourceNote:'Publication metadata is based on the supplied CV, with verified publisher and repository links where available.',
 },
 zh: {
 nav:['个人简介','最新动态','学术论文','科研项目','学术经历'],
 tagline:'人工智能 · 医学影像分析',heroLine:'理解大脑，\n从连接中学习。',researchLabel:'研究关键词',
 areas:['图神经网络','脑影像分析','医学计算机视觉'],cv:'下载学术简历',scholar:'谷歌学术',email:'电子邮箱',
 about:'个人简介',aboutKicker:'我的研究主线',research:'研究方向',researchSub:'从精细解剖结构，到群体水平的脑网络。',related:'相关论文',
 pubs:'学术论文',pubSub:'图学习、脑疾病与医学影像理解。',selected:'代表性论文',all:'全部论文',allYears:'全部年份',allTopics:'全部方向',empty:'暂无符合筛选条件的论文。',shown:'篇论文',bib:'BibTeX',copy:'复制 BibTeX',copied:'已复制',copyFail:'请在下方选中并复制引用。',
 projects:'科研项目',projectSub:'以主持人身份开展四项获资助研究。',pi:'项目主持人',funds:'元',projectNote:'简历提供了资助计划、项目编号与经费；具体研究课题名称、目标和成果尚未提供。',
 experience:'学术经历',awards:'奖励与荣誉',service:'学术服务',patents:'授权专利',news:'最新动态',newsNote:'日期精度依据简历，未补写具体日期。',
 contact:'欢迎学术交流。',contactSub:'欢迎就相关研究方向探讨合作与交流。',updated:'最后更新',top:'返回顶部',theme:'切换明亮与深色模式',menu:'展开或收起导航',skip:'跳至主要内容',close:'关闭引用',citationNote:'根据简历元数据生成的基础引用；正式引用前请核对出版方记录。',legend:'† 共同第一作者 · * 通讯作者；相关标记与荣誉依据所附简历。',sourceNote:'论文信息依据所附简历整理；已核实的出版方与代码仓库链接附于对应条目。',
 }
};
