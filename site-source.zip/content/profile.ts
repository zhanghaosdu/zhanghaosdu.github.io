export type Lang = 'en' | 'zh';
export type Text = { en: string; zh: string };
export const profile = {
 name: { en: 'Hao Zhang', zh: '张浩' }, email: 'hao.zhang@sdu.edu.cn',
 scholar: 'https://scholar.google.com/citations?user=V0mUC7EAAAAJ&hl=zh-CN',
 github: null, orcid: null, updated: '2026-10-27',
 role: { en: 'Postdoctoral Researcher', zh: '博士后研究人员' },
 institution: { en: 'Shandong University', zh: '山东大学' },
 school: { en: 'School of Software', zh: '软件学院' },
 intro: { en: 'I study how learning from brain networks and medical images can help us better understand brain disorders. My work connects graph neural networks, disease-specific representation learning, and fine-grained medical image analysis.', zh: '我关注如何通过脑网络与医学影像学习，更好地理解脑疾病。研究结合图神经网络、疾病特异性表征学习与精细医学影像分析，探索脑疾病预测、异质性与结构分割问题。' },
 biographyZh: [
 '本人现为山东大学特别资助类博士后，合作导师为软件学院院长崔立真教授。博士毕业于山东大学控制科学与工程学院，“机器智能与系统控制”教育部重点实验室，师从张伟教授（长江特聘）和宋然教授（万人青拔），主要研究机器人辅助手术中的视觉感知与医学影像处理。',
 '一作/通讯在 MedIA、IEEE TMI、JBHI、TBME、TSIPN、BSPC 等领域权威期刊发表 SCI 论文 8 篇，一作在 MICCAI 等顶级会议发表 EI 论文 2 篇。其中，TMI 论文入选 ESI 前 1% 高被引论文，被引 260 余次；MedIA 论文被引超 120 次；2 篇论文入选 IEEE TOP50 月度最受欢迎文章。已授权国家发明专利 2 项，参编 Springer 专著 1 部。',
 '入选国家资助博士后研究人员计划 B 类（国家“博新计划”进入会评）、山东省博士后创新种子培养计划，获中国博士后科学基金面上项目及江苏省青年基金项目资助。获山东省人工智能 2023 年度优秀学术论文奖、ACM（济南）优秀博士论文奖（仅 3 人）、山东大学五四青年科学奖，曾受邀在领域顶会 MICCAI 2020 作口头报告。现任国际学术期刊 Advanced Technology in Neuroscience 和 NeuroMarkers 青年编委，并长期担任 IEEE TMI、TIP、JBHI 及 MICCAI 等期刊和会议审稿人。'
 ],
 bio: [
 { en: 'I am a postdoctoral researcher in the School of Software at Shandong University, working with Prof. Lizhen Cui. I received my Ph.D. in Electronic Information from Shandong University in 2025, where I conducted research in the Key Laboratory of Machine Intelligence and System Control, Ministry of Education, under the supervision of Prof. Wei Zhang and Prof. Ran Song.', zh: '我目前是山东大学软件学院特别资助类博士后，合作导师为崔立真教授。2025 年获得山东大学电子信息专业博士学位，博士期间在“机器智能与系统控制”教育部重点实验室开展研究，师从张伟教授与宋然教授。' },
 { en: 'My research develops graph-based and deep learning methods for medical image understanding. A central thread is learning informative brain network representations across individuals and disorders, alongside disentangling Alzheimer’s disease heterogeneity and preserving fine anatomical structures in medical image segmentation. My current interests also include anatomy-guided image–report representation learning.', zh: '我的研究围绕医学影像理解中的图学习与深度学习方法展开：从个体与群体脑网络中提取有效表征，探索跨疾病的泛化能力，解耦阿尔茨海默病异质性，并在医学影像分割中保留精细解剖结构。目前也关注解剖引导的影像—报告表征学习。' },
 { en: 'Before my doctoral studies, I received my master’s degree from Capital Normal University and undertook joint research training at the Ningbo Institute of Materials Technology and Engineering, Chinese Academy of Sciences. My long-term research goal is to make medical image representations more informative and useful for understanding disease.', zh: '博士之前，我在首都师范大学获得硕士学位，并曾在中国科学院宁波材料技术与工程研究所接受联合培养。我的长期研究目标是构建更具信息量的医学影像表征，为疾病理解提供有价值的计算方法。' }
 ],
};
export const interests = [
 { id:'graph', icon:'network', title:{en:'Brain Network Learning',zh:'脑网络图学习'}, desc:{en:'Local-to-global and heterophily-aware graph models for brain disorder prediction; invariant subgraphs for representations across disorders.',zh:'研究局部到全局、异配性感知图模型，用于脑疾病预测；通过不变子图学习探索跨疾病表征。'}, papers:['lg-gnn','spectral','is-gnn'] },
 { id:'neuro', icon:'brain', title:{en:'Disease Heterogeneity',zh:'脑疾病异质性分析'}, desc:{en:'Disentangling disease-specific neuroanatomical variation and identifying Alzheimer’s disease subtypes from brain imaging.',zh:'从脑影像中解耦疾病特异性的神经解剖变异，探索阿尔茨海默病亚型及结构连接改变。'}, papers:['disad','mind'] },
 { id:'segmentation', icon:'scan', title:{en:'Medical Image Segmentation',zh:'医学影像分割'}, desc:{en:'Edge-aware learning for fine vessel-like structures in 3D medical images, with a focus on cerebrovascular segmentation.',zh:'面向三维医学影像中的细微管状结构开展边缘感知学习，重点研究脑血管分割。'}, papers:['er-net','re-net'] },
 { id:'multimodal', icon:'layers', title:{en:'Medical Vision–Language Learning',zh:'医学视觉语言学习'}, desc:{en:'Anatomy-guided alignment of chest X-rays and reports for medical image representation learning.',zh:'利用解剖先验对齐胸部 X 光影像与报告，研究医学影像表征学习。'}, papers:['agira'] }
];
export const experience = [
 {time:'2025.09 —',title:{en:'Postdoctoral Researcher',zh:'特别资助类博士后'},place:{en:'Shandong University · School of Software',zh:'山东大学 · 软件学院'},note:{en:'Postdoctoral advisor: Prof. Lizhen Cui',zh:'合作导师：崔立真教授'}},
 {time:'2021.09 — 2025.06',title:{en:'Ph.D. in Electronic Information',zh:'电子信息 · 博士'},place:{en:'Shandong University',zh:'山东大学'},note:{en:'Advisors: Prof. Wei Zhang & Prof. Ran Song',zh:'导师：张伟教授、宋然教授'}},
 {time:'2019.08 — 2021.01',title:{en:'Joint Master’s Research Training',zh:'联合培养硕士生'},place:{en:'Ningbo Institute of Materials Technology and Engineering, CAS',zh:'中国科学院宁波材料技术与工程研究所'},note:{en:'Research training during master’s studies',zh:'硕士期间联合科研培养'}},
 {time:'2018.09 — 2021.06',title:{en:'Master’s in Computer Application Technology',zh:'计算机应用技术 · 硕士'},place:{en:'Capital Normal University',zh:'首都师范大学'},note:{en:'',zh:''}},
 {time:'2014.09 — 2018.06',title:{en:'Bachelor’s in Software Engineering',zh:'软件工程 · 本科'},place:{en:'Qufu Normal University',zh:'曲阜师范大学'},note:{en:'',zh:''}}
];
export const awards = [
 ['2025','ACM (Jinan) Outstanding Doctoral Dissertation Award','ACM（济南）优秀博士论文奖'],
 ['2025','May Fourth Youth Science Award, Shandong University','山东大学五四青年科学奖'],
 ['2025','Outstanding Graduate, Shandong University','山东大学优秀毕业生'],
 ['2023, 2024','Ji Defa Scholarship & First-Class Scholarship, Shandong University','山东大学纪德法奖学金、一等奖学金'],
 ['2023','Outstanding Academic Paper in Artificial Intelligence, Shandong Province','山东省人工智能年度优秀学术论文'],
 ['2021','Outstanding Graduate, Capital Normal University','首都师范大学优秀毕业生'],
 ['2016, 2017','Third Prize, National English Competition for College Students (Category C)','全国大学生英语竞赛 C 类国家三等奖（两次）']
];
export const service = [
 {time:'2026.08 —',title:{en:'Young Editorial Board Member',zh:'青年编委'},venues:['Advanced Technology in Neuroscience','NeuroMarkers']},
 {time:'2021 —',title:{en:'Reviewer',zh:'审稿人'},venues:['IEEE TMI','IEEE TIP','IEEE TMM','IEEE JBHI','MICCAI']}
];
export const news = [
 {date:'2026.08',text:{en:'Joined the young editorial boards of Advanced Technology in Neuroscience and NeuroMarkers.',zh:'担任 Advanced Technology in Neuroscience 与 NeuroMarkers 青年编委。'}},
 {date:'2026',text:{en:'New research on brain disorder prediction and Alzheimer’s disease heterogeneity appears in IEEE JBHI and IEEE TBME.',zh:'脑疾病预测与阿尔茨海默病异质性研究发表于 IEEE JBHI 和 IEEE TBME。'}},
 {date:'2026',text:{en:'Leading three newly funded postdoctoral and early-career research projects.',zh:'主持国家资助博士后研究人员计划 B 类、中国博士后科学基金面上项目及江苏省青年基金项目。'}},
 {date:'2025.09',text:{en:'Started as a postdoctoral researcher at Shandong University’s School of Software.',zh:'加入山东大学软件学院，开展博士后研究。'}}
];
export const patents = [
 { title:{en:'Brain disease subtype identification based on contrastive generative learning',zh:'一种基于对比生成学习的脑疾病亚型识别方法及系统'}, number:'ZL 2025 1 1073626.X', authors:'张浩、宋然、王大伟、张伟、杨建宏、王丽萍' },
 { title:{en:'A three-dimensional cerebrovascular segmentation method and storage medium',zh:'一种三维脑血管分割方法及存储介质'}, number:'ZL 2021 1 0360853.6', authors:'夏立坤、张浩' }
];
