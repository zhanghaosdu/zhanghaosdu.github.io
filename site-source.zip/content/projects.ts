export const projects = [
 {id:'GZB20260453',time:'2026–2028',amount:'360,000',name:{en:'National Postdoctoral Researcher Support Program · Category B',zh:'国家资助博士后研究人员计划 B 类'},source:{en:'National Postdoctoral Researcher Support Program',zh:'国家资助博士后研究人员计划'}},
 {id:'2026M791843',time:'2026–2028',amount:'80,000',name:{en:'China Postdoctoral Science Foundation · General Program',zh:'中国博士后科学基金面上项目'},source:{en:'China Postdoctoral Science Foundation',zh:'中国博士后科学基金'}},
 {id:'BK20261360',time:'2026–2029',amount:'200,000',name:{en:'Jiangsu Provincial Youth Science Fund',zh:'江苏省青年基金项目'},source:{en:'Jiangsu Provincial Science Fund',zh:'江苏省科学基金'}},
 {id:'SDZZ-ZR-202501303',time:'2025–2027',amount:'30,000',name:{en:'Shandong Postdoctoral Innovation Seed Program',zh:'山东省博士后创新种子培养计划'},source:{en:'Shandong Provincial Postdoctoral Program',zh:'山东省博士后培养计划'}}
];
