"""Package the public static output and editable source for GitHub Pages."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parent.parent
if not (root / 'out' / 'index.html').is_file():
    raise SystemExit('Run pnpm build before packaging.')

with ZipFile(root / 'site-build.zip', 'w', ZIP_DEFLATED) as archive:
    for file in sorted((root / 'out').rglob('*')):
        if file.is_file():
            archive.write(file, file.relative_to(root / 'out'))

names = ['app', 'content', 'public', 'scripts', 'package.json', 'pnpm-lock.yaml',
         'tsconfig.json', 'next.config.ts', 'next-env.d.ts', 'postcss.config.mjs',
         '.gitignore', 'README.md', 'CONTENT-REVIEW.md']
with ZipFile(root / 'site-source.zip', 'w', ZIP_DEFLATED) as archive:
    for name in names:
        item = root / name
        files = sorted(item.rglob('*')) if item.is_dir() else [item]
        for file in files:
            if file.is_file() and '__pycache__' not in file.parts:
                archive.write(file, file.relative_to(root))
print('Created site-build.zip and site-source.zip')
