const fs=require('fs'),ts=require('typescript'),Module=require('module');
const output={};
for(const name of ['profile','publications','projects']){
 const source=fs.readFileSync(`content/${name}.ts`,'utf8');
 const js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText;
 const m=new Module(name);m._compile(js,name);Object.assign(output,m.exports);
}
fs.mkdirSync('tmp',{recursive:true});fs.writeFileSync('tmp/content.json',JSON.stringify(output,null,2));
