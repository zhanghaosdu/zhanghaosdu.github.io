import json, pathlib, html
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, KeepTogether
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.lib.enums import TA_LEFT

data=json.loads(pathlib.Path('tmp/content.json').read_text(encoding='utf-8'))
pathlib.Path('public/cv').mkdir(parents=True,exist_ok=True)
pdfmetrics.registerFont(TTFont('Arial','C:/Windows/Fonts/arial.ttf'))
pdfmetrics.registerFont(TTFont('ArialBold','C:/Windows/Fonts/arialbd.ttf'))
pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light'))
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='BodyCV',fontName='Arial',fontSize=9,leading=14,textColor=colors.HexColor('#334155'),spaceAfter=7))
styles.add(ParagraphStyle(name='HeadCV',fontName='ArialBold',fontSize=13,leading=18,textColor=colors.HexColor('#17365d'),spaceBefore=13,spaceAfter=8,keepWithNext=True))
styles.add(ParagraphStyle(name='TitleCV',fontName='ArialBold',fontSize=27,leading=34,textColor=colors.HexColor('#17365d'),spaceAfter=8))
styles.add(ParagraphStyle(name='ChineseCV',fontName='STSong-Light',fontSize=10,leading=15,spaceAfter=6))
story=[]
def esc(t):return html.escape(str(t))
def para(t,style='BodyCV'):story.append(Paragraph(t,styles[style]))
def head(t):para(t,'HeadCV')
para('Hao Zhang','TitleCV')
para('Postdoctoral Researcher | School of Software | Shandong University')
para('Email: <link href="mailto:hao.zhang@sdu.edu.cn" color="#17365d">hao.zhang@sdu.edu.cn</link> | Updated: 27 October 2026')
para('<link href="https://scholar.google.com/citations?user=V0mUC7EAAAAJ" color="#17365d">Google Scholar</link>')
head('Research profile')
for p in data['profile']['bio']:para(esc(p['en']))
head('Research interests')
for r in data['interests']:para(esc(r['title']['en'])+': '+esc(r['desc']['en']))
head('Academic experience & education')
for e in data['experience']:para(esc(e['time'])+' | '+esc(e['title']['en'])+'<br/>'+esc(e['place']['en'])+('<br/>'+esc(e['note']['en']) if e['note']['en'] else ''))
head('Publications')
para('Author order and contribution markers follow the supplied CV. Metadata discrepancies are explicitly noted. Citation counts and journal impact factors are omitted because they change over time.')
for i,p in enumerate(data['publications']):
 authors=', '.join(p['authors'])
 text=f'{i+1}. {esc(authors)}. {esc(p["title"])}. <i>{esc(p["venue"])}</i>, {p["year"]}.'
 if p.get('cofirst'):text+=' Equal contribution: '+esc(', '.join(p['cofirst']))+'.'
 if p.get('corresponding'):text+=' Hao Zhang: corresponding author.'
 if p.get('tags'):text+=' '+esc('; '.join(p['tags']))+'.'
 if p.get('doi'):text+='<br/>DOI: '+esc(p['doi'])
 if p.get('note'):text+='<br/>Metadata note: '+esc(p['note']['en'])
 para(text)
head('Research funding - Principal investigator')
for p in data['projects']:para(esc(p['name']['en'])+'<br/>'+esc(p['id'])+' | '+esc(p['time'])+' | CNY '+esc(p['amount']))
para('Specific project titles, research objectives, technical details, and outputs were not supplied in the original CV.')
head('Granted patents')
for p in data['patents']:
 para(esc(p['title']['en'])+'<br/>'+esc(p['number']))
 para(esc(p['authors']),'ChineseCV')
head('Awards & honors')
for date,en,zh in data['awards']:para(esc(date)+' | '+esc(en))
head('Academic service')
for s in data['service']:para(esc(s['time'])+' Present | '+esc(s['title']['en'])+'<br/>'+esc(', '.join(s['venues'])))
def footer(canvas,doc):
 canvas.setFont('Arial',8);canvas.setFillColor(colors.HexColor('#64748b'));canvas.drawString(44,26,'Hao Zhang | Academic CV | Public edition');canvas.drawRightString(551,26,str(doc.page))
doc=SimpleDocTemplate('public/cv/Hao-Zhang-CV.pdf',pagesize=(595.28,841.89),rightMargin=44,leftMargin=44,topMargin=40,bottomMargin=45,title='Hao Zhang - Academic CV',author='Hao Zhang')
doc.build(story,onFirstPage=footer,onLaterPages=footer)
print('Created public/cv/Hao-Zhang-CV.pdf')
